nome = input('Digite seu nome: ')
idade = input('Digite sua idade: ')

print(f'Seu nome é: {nome}')
print(f'Sua idade daqui a cinco anos será: {int(idade)+5}')