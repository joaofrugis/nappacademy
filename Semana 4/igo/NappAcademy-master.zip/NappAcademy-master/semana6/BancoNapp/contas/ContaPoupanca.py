from BancoNapp.contas.Conta import Conta


class ContaPoupanca(Conta):
   pass