from BancoNapp.contas.Conta import Conta


class ContaPessoaJuridica(Conta):
    pass